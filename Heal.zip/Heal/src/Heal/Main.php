<?php

namespace Heal;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{

    public function onEnable(){
    }
    
    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{
    
        switch($cmd->getName()){
        
            case "heal":
                if($sender instanceof Player){
                    $sender->sethealth("20.0");
                    $sender->sendmessage("§l(§f!§r§l)§3You Have Been Healed");
                    $sender->addTitle("§6§fYou Have Healed");
                }
            break;
            
        }
        return true;
    }
}